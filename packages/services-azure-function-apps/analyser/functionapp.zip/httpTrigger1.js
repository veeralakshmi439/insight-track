const { ServiceBusClient } = require("@azure/service-bus");

module.exports = async function (context, req) {
  context.log("HTTP trigger function processed a request.");

  // Connection string to your Service Bus namespace
  const connectionString = process.env["SERVICEBUS_CONNECTION_STRING"];
  // Name of the queue
  const queueName = process.env["SERVICEBUS_QUEUE_NAME"];

  // Create a Service Bus client
  const sbClient =
    ServiceBusClient.createFromConnectionString(connectionString);
  // Create a sender for the queue
  const sender = sbClient.createQueueClient(queueName).createSender();

  try {
    // The message to send to the queue
    const message = {
      body: req.body.message || "Default message",
      label: req.body.label || "Default label",
    };

    // Send the message to the queue
    await sender.send(message);
    context.log(`Message sent to queue: ${queueName}`);
    context.res = {
      // status: 200, /* Defaults to 200 */
      body: `Message sent to queue: ${queueName}`,
    };
  } catch (err) {
    context.log.error(`Error sending message to queue: ${err.message}`);
    context.res = {
      status: 500,
      body: `Error sending message to queue: ${err.message}`,
    };
  } finally {
    // Close the sender
    await sender.close();
    // Close the Service Bus client
    await sbClient.close();
  }
};
